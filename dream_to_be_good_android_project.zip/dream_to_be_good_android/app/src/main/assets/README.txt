DREAM TO BE GOOD — HARD 20-COLOR EDITION
Created by Rasheed • Game Creator

NETLIFY DEPLOY
1. Keep index.html and the images folder together.
2. Upload the complete folder to Netlify.
3. No build command is required.
4. Publish the folder containing index.html.

GAME
- 1,000 levels
- Every level is HARD
- 20 different liquid colors
- 22 containers total: 20 full mixed bottles + 2 empty glasses
- 2 rows x 11 bottles on the board
- Every full starting bottle contains 4 different colors
- Bottle silhouettes change every 10 levels
- Every 10th level shows the BONUS EMPTY GLASS treatment
- The 20-color puzzle is built from five independently solvable hard 4-color blocks, so the generated layouts remain solvable while every full bottle is mixed
- Undo, Restart, Hint, Previous, Next, level selector
- Sound toggle and pour/selection animations
- Browser progress persistence
- Creator milestone gallery at levels 100, 200, ... 1000
- No external libraries or CDN dependencies
